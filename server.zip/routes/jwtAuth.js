const express = require("express");
const router = express.Router();
const bcrypt = require("bcrypt");
const pool = require("../db");
const validInfo = require("../middleware/validInfo");
const jwtGenerator = require("../utils/jwtGenerator");
const authorize = require("../middleware/authorize");

//delete profile
router.delete("/deleteProfile", validInfo, async (req, res) => {
  const { currentID} = req.body;
  try {

    await pool.query(
      "DELETE FROM users WHERE user_id = $1",
      [currentID] // insert encrypted pw into database
    );
    return res.json();

  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server error");
  }
});

//edit profile route
router.put("/profile", validInfo, async (req, res) => {
  const { currentID, editName, editPassword } = req.body;
  try {
    
    /* some logic to fix if user email exists
    const checkUserExists = await pool.query("SELECT * FROM users WHERE user_email = $1", [
      editEmail,
    ]);
    if (checkUserExists.rows.length > 0) {
      // if user exist, i.e return 1 row, then dont UPDATE
      return res.status(401).json("User already exist!");
    } */

    const salt = await bcrypt.genSalt(10);
    const editBcryptPassword = await bcrypt.hash(editPassword, salt);

    let editUser = await pool.query(
      // does not give u editUser.rows
      "UPDATE users SET user_name = $2, user_password = $3 WHERE user_id = $1",
      [currentID, editName, editBcryptPassword] // insert encrypted pw into database
    );

    // regenerate jwt token
    const user = await pool.query("SELECT * FROM users WHERE user_id = $1", [
      currentID, // value of $1 goes to email
    ]);
    const jwtToken = jwtGenerator(user.rows[0].user_id);
    return res.json({ jwtToken });
    //
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server error");
  }
});

//register route
router.post("/register", validInfo, async (req, res) => {
  const { email, name, password } = req.body; // destructure the req.body
  try {
    const user = await pool.query("SELECT * FROM users WHERE user_email = $1", [
      email, // value of $1 goes to email
    ]);

    // user.rows from psql, contains user_id, user_name, user_email etc
    if (user.rows.length > 0) {
      // if user exist, i.e return 1 row, then dont register
      return res.status(401).json("User already exist!");
    }

    const salt = await bcrypt.genSalt(10);
    const bcryptPassword = await bcrypt.hash(password, salt);

    let newUser = await pool.query(
      "INSERT INTO users (user_name, user_email, user_password) VALUES ($1, $2, $3) RETURNING *",
      [name, email, bcryptPassword] // insert encrypted pw into database
    );

    const jwtToken = jwtGenerator(newUser.rows[0].user_id); // generate jwt token

    return res.json({ jwtToken });
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server error");
  }
});

router.post("/login", validInfo, async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await pool.query("SELECT * FROM users WHERE user_email = $1", [
      email,
    ]);

    if (user.rows.length === 0) {
      // if psql returns no row, i.e user_email doesnt exist
      return res.status(401).json("Invalid Credential");
    }

    const validPassword = await bcrypt.compare(
      password, // password from req.body
      user.rows[0].user_password // password from psql
    );

    if (!validPassword) {
      return res.status(401).json("Invalid Credential");
    }
    const jwtToken = jwtGenerator(user.rows[0].user_id);
    return res.json({ jwtToken });
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server error");
  }
});

router.post("/verify", authorize, (req, res) => {
  // validate jwttoken valid anot
  try {
    res.json(true);
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server error");
  }
});



module.exports = router;


