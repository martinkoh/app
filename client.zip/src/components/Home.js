import React from "react";
import { Link } from "react-router-dom";
import logo from './sp logo.jfif'; 


const Home = () => {
  return (
    <div>
                
      <nav className="navbar mt-3">
        <img width={100} height={100}src={logo} />
        <h1>Anime Merchandise Store</h1>
      </nav>
      <div className="jumbotron mt-5">
        
        <div class="container">
  <div class="row">
    <div class="col">
      <div class="card" >
  <div class="card-body">
    <h5 class="card-title">I am an existing customer.</h5>
    <p class="card-text">Login to view products.</p>
    <Link to="/login" className="btn btn-primary">
          Login
        </Link>
  </div>
</div>
    </div>
    <div class="col">
      <div class="card" >
  <div class="card-body">
    <h5 class="card-title">I am a new customer.</h5>
    <p class="card-text">Sign up to view products.</p>
    <Link to="/register" className="btn btn-primary">
          Register
        </Link>
  </div>
</div>
    </div>
  </div>
</div>
        
      
        </div>
    </div>
  );
};

export default Home;
