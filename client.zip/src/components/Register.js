import React, { Fragment, useState } from "react";
import { Link, Redirect } from "react-router-dom";
import { toast } from "react-toastify";

const Register = ({ setAuth }) => {

  const [inputs, setInputs] = useState({
    email: "", //these values are replaced by HTML placeholder values
    password: "",
    name: ""
  });
  const { email, password, name } = inputs;

  const onChange = e =>
    setInputs({ ...inputs, [e.target.name]: e.target.value }); //

  const onSubmitForm = async e => { // submit to rest API to get jwt token
    e.preventDefault(); // prevent refresh
    try {
      const body = { email, password, name };
      const response = await fetch(
        "/authentication/register",
        {
          method: "POST",
          headers: {
            "Content-type": "application/json",
          },
          body: JSON.stringify(body),
        }
      );
      const parseRes = await response.json(); //returns jwt token, from backend, jwtauth.js: return res.json({ jwtToken });

      if (parseRes.jwtToken) {
        localStorage.setItem("token", parseRes.jwtToken);
        setAuth(true);
        toast.success("Register Successfully");
      } else {
        setAuth(false);
        toast.error(parseRes);
      }
    } catch (err) {
      console.error(err.message);
    }
  };



  return (
    <Fragment>
      <h1 className="mt-5 text-center">Register</h1>
      <form onSubmit={onSubmitForm}>
        <input
          type="text"
          name="email"
          value={email} // to the inputs
          placeholder="email"
          onChange={(e) => onChange(e)}
          className="form-control my-3" //margin "y" of 3
        />
        <input
          type="password"
          name="password"
          value={password} // to the inputs
          placeholder="password"
          onChange={(e) => onChange(e)}
          className="form-control my-3"
        />
        <input
          type="text"
          name="name"
          value={name} // to the inputs
          placeholder="name"
          onChange={(e) => onChange(e)}
          className="form-control my-3"
        />
        <button className="btn btn-dark ">Submit</button>
      </form>
      <Link to="/login">Login</Link>
    </Fragment>
  );
};

export default Register;
