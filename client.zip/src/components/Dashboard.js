import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";

const Dashboard = ({ setAuth }) => {

  const [name, setName] = useState("");
  const getProfile = async () => {
    try {
      const res = await fetch("/", {
        method: "GET",
        headers: { jwt_token: localStorage.token }
      });

      const parseData = await res.json();
      setName(parseData.user_name);
    } catch (err) {
      console.error(err.message);
    }
  };

  useEffect(() => {
    getProfile();
  }, []);



const logout = async (e) => {
  e.preventDefault();
  try {
    localStorage.removeItem("token");
    setAuth(false);
    toast.success("Logout successfully"); // notification
  } catch (err) {
    console.error(err.message);
  }
};

  return (
    <div>
      <div className="mt-5"></div>
      <h2>Welcome {name}</h2>
      <Link to="/profile" className="btn btn-dark">
        My Profile
      </Link>
      <button onClick={(e) => logout(e)} className="btn btn-primary">
        Logout
      </button>

      <h1 className="mt-5">Products On Sale</h1>
      <div class="row">
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Shirt</h5>
        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
        <a href="#" class="btn btn-primary">Go somewhere</a>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Blouse</h5>
        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
        <a href="#" class="btn btn-primary">Go somewhere</a>
      </div>
    </div>
  </div>
</div>
      
    </div>
  );
};



export default Dashboard;
